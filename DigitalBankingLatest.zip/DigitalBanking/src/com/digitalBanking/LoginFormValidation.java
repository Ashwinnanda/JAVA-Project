package com.digitalBanking;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession; 
@WebServlet("/LoginFormValidation")
public class LoginFormValidation extends HttpServlet{
	private static final long serialVersionUID = 1L;
		Pattern usernamePattern = Pattern.compile("[a-zA-Z0-9]+"); 
		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			response.setContentType("text/html");
			String userName = request.getParameter("UserName");
			String password = request.getParameter("Password");
			Matcher match = usernamePattern.matcher(userName);
			Integer userNameLength = userName.length();
			Integer passwordLength = password.length();
			if ((userNameLength >= 3) && (userNameLength <= 32) && (passwordLength >= 8) && (passwordLength <= 20) && match.matches()) {				
				request.setAttribute("errorMessage", "");
				HttpSession session = request.getSession();				
				session.setAttribute("usernameSession", "Welcome "+userName);
		    	request.getRequestDispatcher("HomePage.jsp").forward(request, response);
			} else {
				request.setAttribute("errorMessage", "Invalid Credentials");
		    	request.getRequestDispatcher("LoginPage.jsp").forward(request, response);
			}		
		}
}
