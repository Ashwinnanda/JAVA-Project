package com.digitalBanking;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/ExistingCustomerFormValidation")
public class ExistingCustomerFormValidation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Pattern balancePattern = Pattern.compile("^[0-9]+$"); 
	public static final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
	public static final String JDBC_URL = "jdbc:derby:DigitalBankingDB";
	Connection connection = null;
    public ExistingCustomerFormValidation() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);		
		response.setContentType("text/html");
		String lastmonthbalance = request.getParameter("LastMonthBalance");
		String lastbeforemonthbalance = request.getParameter("LastBeforeMonthBalance");
		Matcher matchlastmonthbalance = balancePattern.matcher(lastmonthbalance);
		Matcher matchlastbeforemonthbalance = balancePattern.matcher(lastbeforemonthbalance);
		Integer lastmonthbalanceLength = lastmonthbalance.length();
		Integer lastbeforemonthbalanceLength = lastbeforemonthbalance.length();
		String sql = "";
		Boolean executeAverageBalanceQuery = false;
		String avarageBalanceString = "";
		float savingsPointsFloat = 0;
		if (matchlastmonthbalance.matches() && lastmonthbalanceLength <= 10 && matchlastbeforemonthbalance.matches() && lastbeforemonthbalanceLength <= 10) {
			float lastmonthbalanceinteger = Float.parseFloat(lastmonthbalance);
			float lastbeforemonthbalanceinteger = Float.parseFloat(lastbeforemonthbalance);
			float avarageBalance = (lastmonthbalanceinteger+lastbeforemonthbalanceinteger) / 2;
			DecimalFormat df = new DecimalFormat("#.00");
			df.format(avarageBalance);	
			if (avarageBalance <=2000.00) {
				avarageBalanceString = "Below 2000";
				executeAverageBalanceQuery = true;
			}
			if (avarageBalance >=2100.00 && avarageBalance <=4000.00) {
				avarageBalanceString = "2100 � 4000";
				executeAverageBalanceQuery = true;
			}
			if (avarageBalance >=4000.00 && avarageBalance <=40000.00) {
				avarageBalanceString = "4100 � 40000";
				executeAverageBalanceQuery = true;
			}
			if (avarageBalance >= 41000.00) {
				avarageBalanceString = "Above 41000";
				executeAverageBalanceQuery = true;
			}
			try {
				Class.forName(DRIVER);
				connection = DriverManager.getConnection(JDBC_URL);
			if (executeAverageBalanceQuery == true) {
				sql = "SELECT POINTS FROM AVERAGE_BALANCE_POINTS WHERE AVERAGE_BALANCE = ?";
				PreparedStatement preparedStatement = connection.prepareStatement(sql);	
				preparedStatement.setString(1, avarageBalanceString);
				ResultSet resultset = preparedStatement.executeQuery();
				String savingsPoints = "";
				while (resultset.next()) {
					savingsPoints = resultset.getString(1);					
				}
				savingsPointsFloat = Float.parseFloat(savingsPoints);
			}
			DecimalFormat df1 = new DecimalFormat("#.00");
			df1.format(savingsPointsFloat);
			if (savingsPointsFloat <= 0.49) {
				sql = "SELECT * FROM SAVINGS_PLAN_DATA WHERE SAVINGS_POINTS = '0.1 - 0.49'";								
			}
			if (savingsPointsFloat > 0.49 && savingsPointsFloat <= 0.99) {
				sql = "SELECT * FROM SAVINGS_PLAN_DATA WHERE SAVINGS_POINTS = '0.5 - 0.99'";				
			}
			if (savingsPointsFloat >= 1.00) {
				sql = "SELECT * FROM SAVINGS_PLAN_DATA WHERE SAVINGS_POINTS = 'Above 1.0'";
			}
			PreparedStatement preparedStatement = connection.prepareStatement(sql);	
			ResultSet resultset = preparedStatement.executeQuery();	
			ResultSetMetaData resultsetmetadata = resultset.getMetaData();
			int columnCount = resultsetmetadata.getColumnCount();	
			for (int x = 1; x <= columnCount; x++) {
				String value = resultsetmetadata.getColumnName(x);
				request.setAttribute("columnName"+x, value);
			}
			int rowCount = 0;
			while (resultset.next()) {
					
					for (int x = 1; x <= columnCount; x++) {
						String rowValue = resultset.getString(x);
						request.setAttribute("rowValue"+rowCount+x, rowValue);
					}						
				rowCount = rowCount+1;				
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
			request.setAttribute("tableVisibility", "Block");
			request.setAttribute("radioButtonVisibility", "none");
			request.getRequestDispatcher("SavingsAdvisorLandingPage.jsp").forward(request, response);
		} else {
			request.setAttribute("radioButtonVisibility", "Block");
			request.setAttribute("tableVisibility", "none");
			request.setAttribute("existingCustomerFormVisibility", "Block");
			request.setAttribute("errorMessageExisting", "Invalid Input");
	    	request.getRequestDispatcher("SavingsAdvisorLandingPage.jsp").forward(request, response);
		}
	}
}
