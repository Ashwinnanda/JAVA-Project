package com.digitalBanking;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/NewCustomerFormValidation")
public class NewCustomerFormValidation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Pattern usernamePattern = Pattern.compile("^[0-9]+$"); 
	public static final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
	public static final String JDBC_URL = "jdbc:derby:DigitalBankingDB";
	Connection connection = null;
    public NewCustomerFormValidation() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	@SuppressWarnings({ "unused" })
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		PrintWriter printwriter = response.getWriter();
		response.setContentType("text/html");
		String age = request.getParameter("Age");
		String income = request.getParameter("Income");
		Matcher matchage = usernamePattern.matcher(age);
		Matcher matchincome = usernamePattern.matcher(income);
		Integer ageLength = age.length();
		Integer incomeLength = income.length();
		String sql = "";
		if (matchage.matches() && matchincome.matches() && ageLength > 0 && ageLength <= 3 && incomeLength > 0 && incomeLength <= 10) {
			int ageinteger = Integer.parseInt(age);
			int incomeinteger = Integer.parseInt(income);
			float agePointsInteger = 0;
			float incomePointsInteger = 0;
			Boolean executeAgeQuery = false;
			Boolean executeIncomeQuery = false;
			if (ageinteger >= 20 && ageinteger <= 30) {
				age = "20-30";
				executeAgeQuery = true;
			}
			if (ageinteger >= 31 && ageinteger <= 40) {
				age = "31-40";
				executeAgeQuery = true;
			}
			if(ageinteger >= 41 && ageinteger <= 50) {
				age = "41-50";
				executeAgeQuery = true;
			}
			if (ageinteger > 50) {
				age = "Above 50";
				executeAgeQuery = true;
			}
			if (incomeinteger <=20000) {
				income = "Below 20000";
				executeIncomeQuery = true;
			}
			if (incomeinteger >=21000 && incomeinteger <=30000) {
				income = "21000 � 30000";
				executeIncomeQuery = true;
			}
			if (incomeinteger >=31000 && incomeinteger <=40000) {
				income = "31000 � 40000";
				executeIncomeQuery = true;
			}
			if (incomeinteger > 40000) {
				income = "Above 40000";
				executeIncomeQuery = true;
			}
			try {
				Class.forName(DRIVER);
				connection = DriverManager.getConnection(JDBC_URL);
				if (executeAgeQuery == true) {
					sql = "SELECT POINTS FROM AGE_SAVINGS_POINTS WHERE AGE = ?";
					PreparedStatement preparedStatement = connection.prepareStatement(sql);	
					preparedStatement.setString(1, age);
					ResultSet resultset = preparedStatement.executeQuery();
					ResultSetMetaData resultsetmetadata = resultset.getMetaData();
					String agePoints = "";
					while (resultset.next()) {
						agePoints = resultset.getString(1);
					}	
					agePointsInteger = Float.parseFloat(agePoints);
				}
				if (executeIncomeQuery == true) {
					sql = "SELECT POINTS FROM INCOME_SAVINGS_POINTS WHERE INCOME = ?";
					PreparedStatement preparedStatement = connection.prepareStatement(sql);	
					preparedStatement.setString(1, income);
					ResultSet resultset = preparedStatement.executeQuery();
					ResultSetMetaData resultsetmetadata = resultset.getMetaData();
					String incomePoints = "";
					while (resultset.next()) {
						incomePoints = resultset.getString(1);					
					}
					incomePointsInteger = Float.parseFloat(incomePoints);	
				}
				float savingsPoints = ( agePointsInteger + incomePointsInteger ) / 2 ;
				DecimalFormat df = new DecimalFormat("#.00");
				df.format(savingsPoints);
				if (savingsPoints <= 0.49) {
					sql = "SELECT * FROM SAVINGS_PLAN_DATA WHERE SAVINGS_POINTS = '0.1 - 0.49'";									
				}
				if (savingsPoints > 0.49 && savingsPoints <= 0.99) {
					sql = "SELECT * FROM SAVINGS_PLAN_DATA WHERE SAVINGS_POINTS IN (('0.1 - 0.49'), ('0.5 - 0.99'))";					
				}
				if (savingsPoints >= 1.00) {
					sql = "SELECT * FROM SAVINGS_PLAN_DATA WHERE SAVINGS_POINTS IN (('0.1 - 0.49'), ('0.5 - 0.99'), ('Above 1.0'))";
				}
				PreparedStatement preparedStatement = connection.prepareStatement(sql);	
				ResultSet resultset = preparedStatement.executeQuery();	
				ResultSetMetaData resultsetmetadata = resultset.getMetaData();
				int columnCount = resultsetmetadata.getColumnCount();	
				for (int x = 1; x <= columnCount; x++) {
					String value = resultsetmetadata.getColumnName(x);
					request.setAttribute("columnName"+x, value);
				}
				int rowCount = 0;
				while (resultset.next()) {
							for (int x = 1; x <= columnCount; x++) {
							String rowValue = resultset.getString(x);
							request.setAttribute("rowValue"+rowCount+x, rowValue);
						}						
					rowCount = rowCount+1;				
				}
				
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
			request.setAttribute("tableVisibility", "Block");
			request.setAttribute("radioButtonVisibility", "none");
			request.getRequestDispatcher("SavingsAdvisorLandingPage.jsp").forward(request, response);
		} else {
			request.setAttribute("radioButtonVisibility", "Block");
			request.setAttribute("tableVisibility", "none");
			request.setAttribute("newCustomerFormVisibility", "Block");
			request.setAttribute("errorMessage", "Invalid Input");
	    	request.getRequestDispatcher("SavingsAdvisorLandingPage.jsp").forward(request, response);
		}	
	}
}
