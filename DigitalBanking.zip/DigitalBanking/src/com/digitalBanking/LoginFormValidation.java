package com.digitalBanking;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession; 
@WebServlet("/LoginFormValidation")
public class LoginFormValidation extends HttpServlet{
	private static final long serialVersionUID = 1L;
		Pattern usernamePattern = Pattern.compile("[a-zA-Z0-9]+"); 
		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			response.setContentType("text/html");
			String userName = request.getParameter("UserName");
			String password = request.getParameter("Password");
			//System.out.println(userName);
			//System.out.println(password);
			Matcher match = usernamePattern.matcher(userName);
			//System.out.println(match.matches());
			Integer userNameLength = userName.length();
			Integer passwordLength = password.length();
			//System.out.println(userNameLength);
			//System.out.println(passwordLength);
			if ((userNameLength >= 3) && (userNameLength <= 32) && (passwordLength >= 8) && (passwordLength <= 20) && match.matches()) {				
				request.setAttribute("errorMessage", "");
				HttpSession session = request.getSession();				
				session.setAttribute("usernameSession", "Welcome "+userName);
				//String usernameInSession = (String) session.getAttribute("usernameSession");
				//request.setAttribute("name", "Welcome "+usernameInSession);
		    	request.getRequestDispatcher("HomePage.jsp").forward(request, response);
			} else {
				//System.out.println("Validation failed");
				request.setAttribute("errorMessage", "Invalid Credentials");
		    	request.getRequestDispatcher("LoginPage.jsp").forward(request, response);
			}
			
		}

}
