package com.digitalBanking;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ExistingCustomerFormValidation")
public class ExistingCustomerFormValidation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Pattern balancePattern = Pattern.compile("^[0-9]+$"); 
	public static final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
	public static final String JDBC_URL = "jdbc:derby:DigitalBankingDB";
	Connection connection = null;
    public ExistingCustomerFormValidation() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		//PrintWriter printwriter = response.getWriter();
		response.setContentType("text/html");
		String lastmonthbalance = request.getParameter("LastMonthBalance");
		String lastbeforemonthbalance = request.getParameter("LastBeforeMonthBalance");
		Matcher matchlastmonthbalance = balancePattern.matcher(lastmonthbalance);
		Matcher matchlastbeforemonthbalance = balancePattern.matcher(lastbeforemonthbalance);
		Integer lastmonthbalanceLength = lastmonthbalance.length();
		Integer lastbeforemonthbalanceLength = lastbeforemonthbalance.length();
		String sql = "";
		Boolean executeAverageBalanceQuery = false;
		String avarageBalanceString = "";
		float savingsPointsFloat = 0;
		if (matchlastmonthbalance.matches() && lastmonthbalanceLength <= 10 && matchlastbeforemonthbalance.matches() && lastbeforemonthbalanceLength <= 10) {
			float lastmonthbalanceinteger = Float.parseFloat(lastmonthbalance);
			float lastbeforemonthbalanceinteger = Float.parseFloat(lastbeforemonthbalance);
			float avarageBalance = (lastmonthbalanceinteger+lastbeforemonthbalanceinteger) / 2;
			DecimalFormat df = new DecimalFormat("#.00");
			df.format(avarageBalance);
			//System.out.println(avarageBalance);	
			if (avarageBalance <=2000.00) {
				avarageBalanceString = "Below 2000";
				executeAverageBalanceQuery = true;
			}
			if (avarageBalance >=2100.00 && avarageBalance <=4000.00) {
				avarageBalanceString = "2100 � 4000";
				executeAverageBalanceQuery = true;
			}
			if (avarageBalance >=4000.00 && avarageBalance <=40000.00) {
				avarageBalanceString = "4100 � 40000";
				executeAverageBalanceQuery = true;
			}
			if (avarageBalance >= 41000.00) {
				avarageBalanceString = "Above 41000";
				executeAverageBalanceQuery = true;
			}
			try {
				Class.forName(DRIVER);
				connection = DriverManager.getConnection(JDBC_URL);
				//System.out.println("DB Connected");
				//System.out.println(avarageBalanceString);
			if (executeAverageBalanceQuery == true) {
				sql = "SELECT POINTS FROM AVERAGE_BALANCE_POINTS WHERE AVERAGE_BALANCE = ?";
				PreparedStatement preparedStatement = connection.prepareStatement(sql);	
				preparedStatement.setString(1, avarageBalanceString);
				ResultSet resultset = preparedStatement.executeQuery();
				//ResultSetMetaData resultsetmetadata = resultset.getMetaData();
				//int columnCount = resultsetmetadata.getColumnCount();
				String savingsPoints = "";
				while (resultset.next()) {
					savingsPoints = resultset.getString(1);					
				}
				savingsPointsFloat = Float.parseFloat(savingsPoints);
				//System.out.println(savingsPointsFloat);	
			}
			//float savingsPoints = ( agePointsInteger + incomePointsInteger ) / 2 ;
			DecimalFormat df1 = new DecimalFormat("#.00");
			df1.format(savingsPointsFloat);
			//System.out.println(savingsPointsFloat);
			//String savingsPointsString = String.valueOf(savingsPointsFloat);
			//System.out.println(savingsPointsString);
			if (savingsPointsFloat <= 0.49) {
				sql = "SELECT * FROM SAVINGS_PLAN_DATA WHERE SAVINGS_POINTS = '0.1 - 0.49'";				
				//preparedStatement.setString(1, "0.1 - 0.49");					
			}
			if (savingsPointsFloat > 0.49 && savingsPointsFloat <= 0.99) {
				sql = "SELECT * FROM SAVINGS_PLAN_DATA WHERE SAVINGS_POINTS = '0.5 - 0.99'";
				//System.out.println("INSIDE 2ND QUERY");					
			}
			if (savingsPointsFloat >= 1.00) {
				sql = "SELECT * FROM SAVINGS_PLAN_DATA WHERE SAVINGS_POINTS = 'Above 1.0'";
				//System.out.println("INSIDE 3RD QUERY");
			}
			PreparedStatement preparedStatement = connection.prepareStatement(sql);	
			ResultSet resultset = preparedStatement.executeQuery();	
			ResultSetMetaData resultsetmetadata = resultset.getMetaData();
			//System.out.println(resultsetmetadata);
			int columnCount = resultsetmetadata.getColumnCount();	
			//int rowCount = resultset.getRow();
			//System.out.println("rows:"+rowCount);
			//String[] columnnames = new String[columnCount+1];
			for (int x = 1; x <= columnCount; x++) {
				String value = resultsetmetadata.getColumnName(x);
				request.setAttribute("columnName"+x, value);
				//System.out.println("test"+x);
			}
			int rowCount = 0;
			while (resultset.next()) {
					
					for (int x = 1; x <= columnCount; x++) {
						String rowValue = resultset.getString(x);
						//System.out.println("row: "+rowCount);
						request.setAttribute("rowValue"+rowCount+x, rowValue);
						
						//System.out.println(rowValue);
						//System.out.println("rowValue"+rowCount+x);
					}						
				rowCount = rowCount+1;				
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			request.setAttribute("tableVisibility", "Block");
			request.setAttribute("radioButtonVisibility", "none");
			request.getRequestDispatcher("SavingsAdvisorLandingPage.jsp").forward(request, response);
		} else {
			//System.out.println("Validation failed");
			request.setAttribute("radioButtonVisibility", "Block");
			request.setAttribute("tableVisibility", "none");
			request.setAttribute("existingCustomerFormVisibility", "Block");
			request.setAttribute("errorMessageExisting", "Invalid Input");
	    	request.getRequestDispatcher("SavingsAdvisorLandingPage.jsp").forward(request, response);
			
		}
	}

}
